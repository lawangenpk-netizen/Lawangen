import 'dart:math' as math;
import 'package:flutter_test/flutter_test.dart';
import 'package:bank_shot_pro/engine/engine.dart';

void main() {
  const table = TableSpec(); // 254 x 127 cm, r = 2.85
  const engine = ShotEngine(table);
  final r = table.ballRadius;

  Vec2 imageOf(Vec2 target, List<Wall> walls) {
    var p = target;
    for (final w in walls.reversed) {
      p = table.reflect(p, w);
    }
    return p;
  }

  /// Checks the law of reflection at every cushion contact.
  void expectReflection(ShotRoute route) {
    final pts = route.objectPath;
    for (var i = 0; i < route.walls.length; i++) {
      final w = route.walls[i];
      final p = pts[i + 1];
      final inD = (p - pts[i]).unit;
      final outD = (pts[i + 2] - p).unit;
      if (w.isVertical) {
        expect(p.x, closeTo(table.wallCoord(w), 1e-9));
        expect(outD.x, closeTo(-inD.x, 1e-9));
        expect(outD.y, closeTo(inD.y, 1e-9));
      } else {
        expect(p.y, closeTo(table.wallCoord(w), 1e-9));
        expect(outD.y, closeTo(-inD.y, 1e-9));
        expect(outD.x, closeTo(inD.x, 1e-9));
      }
    }
  }

  test('coordinate conversion round-trips', () {
    const tf = TableTransform(table, 800);
    final s = tf.toScreen(const Vec2(100, 50));
    final t = tf.toTable(s.x, s.y);
    expect(t.x, closeTo(100, 1e-9));
    expect(t.y, closeTo(50, 1e-9));
    expect(tf.heightPx / 800,
        closeTo((127 + 20) / (254 + 20), 1e-12));
  });

  test('reflection across wall planes', () {
    final p = table.reflect(const Vec2(10, 20), Wall.left);
    expect(p.x, closeTo(2 * r - 10, 1e-12));
    expect(p.y, 20);
    final q = table.reflect(const Vec2(10, 20), Wall.bottom);
    expect(q.y, closeTo(2 * (127 - r) - 20, 1e-12));
  });

  test('direct straight shot: ghost ball is 2r behind object, cut = 0', () {
    final route = engine.computeRoute(
        cue: const Vec2(127, 90),
        object: const Vec2(127, 30),
        obstacles: const [],
        pocketIndex: 1,
        walls: const [])!;
    expect(route.ghost.x, closeTo(127, 1e-9));
    expect(route.ghost.y, closeTo(30 + 2 * r, 1e-9));
    expect(route.cutAngleDeg, closeTo(0, 1e-6));
    expect(route.cueDistance, closeTo(90 - 30 - 2 * r, 1e-9));
    expect(route.objectDistance, closeTo(30, 1e-9));
    expect(route.playable, isTrue);
  });

  test('direct shot cut angle matches independent trigonometry', () {
    final route = engine.computeRoute(
        cue: const Vec2(177, 80),
        object: const Vec2(127, 30),
        obstacles: const [],
        pocketIndex: 1,
        walls: const [])!;
    final expected = math.atan2(50, 80 - (30 + 2 * r)) * 180 / math.pi;
    expect(route.cutAngleDeg, closeTo(expected, 1e-6));
    expect(route.ghost.distanceTo(const Vec2(127, 30)), closeTo(2 * r, 1e-9));
  });

  test('too-thin cut is reported', () {
    final route = engine.computeRoute(
        cue: const Vec2(200, 30 + 2 * r),
        object: const Vec2(127, 30),
        obstacles: const [],
        pocketIndex: 1,
        walls: const [])!;
    expect(route.problem, isNotNull);
    expect(route.playable, isFalse);
  });

  const obj = Vec2(100, 40);
  const cue = Vec2(180, 100);

  test('one-cushion bank (bottom) obeys reflection and unfolded length', () {
    final route = engine.computeRoute(
        cue: cue,
        object: obj,
        obstacles: const [],
        pocketIndex: 2,
        walls: const [Wall.bottom])!;
    expect(route.contactPoints.length, 1);
    expectReflection(route);
    final pocket = table.pockets[2].center;
    expect(route.objectDistance,
        closeTo(obj.distanceTo(imageOf(pocket, route.walls)), 1e-9));
  });

  test('two-cushion bank (top, bottom) obeys reflection and unfolded length',
      () {
    final route = engine.computeRoute(
        cue: cue,
        object: obj,
        obstacles: const [],
        pocketIndex: 2,
        walls: const [Wall.top, Wall.bottom])!;
    expect(route.contactPoints.length, 2);
    expectReflection(route);
    final pocket = table.pockets[2].center;
    expect(route.objectDistance,
        closeTo(obj.distanceTo(imageOf(pocket, route.walls)), 1e-9));
  });

  test('three-cushion bank (top, left, bottom) obeys reflection', () {
    final route = engine.computeRoute(
        cue: cue,
        object: obj,
        obstacles: const [],
        pocketIndex: 2,
        walls: const [Wall.top, Wall.left, Wall.bottom])!;
    expect(route.contactPoints.length, 3);
    expectReflection(route);
    final pocket = table.pockets[2].center;
    expect(route.objectDistance,
        closeTo(obj.distanceTo(imageOf(pocket, route.walls)), 1e-9));
  });

  test('obstacle on cue path blocks the shot and is identified', () {
    final route = engine.computeRoute(
        cue: const Vec2(127, 90),
        object: const Vec2(127, 30),
        obstacles: const [BallPos('o0', Vec2(127, 60))],
        pocketIndex: 1,
        walls: const [])!;
    expect(route.blockedBy, 'o0');
    expect(route.blockedLeg, 'cue');
  });

  test('obstacle just clear of the path does not block', () {
    final route = engine.computeRoute(
        cue: const Vec2(127, 90),
        object: const Vec2(127, 30),
        obstacles: [BallPos('o0', Vec2(127 + 2 * r + 0.5, 60))],
        pocketIndex: 1,
        walls: const [])!;
    expect(route.blockedBy, isNull);
  });

  test('obstacle on object path blocks the object leg', () {
    final route = engine.computeRoute(
        cue: const Vec2(127, 90),
        object: const Vec2(127, 30),
        obstacles: const [BallPos('o0', Vec2(127, 15))],
        pocketIndex: 1,
        walls: const [])!;
    expect(route.blockedBy, 'o0');
    expect(route.blockedLeg, 'object');
  });

  test('computeRoutes returns playable routes first, sorted by cushions', () {
    final routes = engine.computeRoutes(
        cue: cue,
        object: obj,
        obstacles: const [],
        pocketIndex: 2,
        maxCushions: 3);
    expect(routes, isNotEmpty);
    expect(routes.any((x) => x.cushions == 1), isTrue);
    expect(routes.any((x) => x.cushions == 2), isTrue);
    expect(routes.any((x) => x.cushions == 3), isTrue);
    var seenUnplayable = false;
    for (final x in routes) {
      if (!x.playable) seenUnplayable = true;
      if (seenUnplayable) expect(x.playable, isFalse);
    }
  });

  test('spin estimate is separate from geometry', () {
    final route = engine.computeRoute(
        cue: cue,
        object: obj,
        obstacles: const [],
        pocketIndex: 2,
        walls: const [Wall.bottom])!;
    final before = route.objectDistance;
    final e = estimateSpin(
        route, const SpinInput(side: 1, vertical: 0.5, power: 1));
    expect(e.spinThrowDeg, greaterThan(0));
    expect(route.objectDistance, before);
  });
}
