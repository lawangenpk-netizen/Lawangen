# Bank Shot Pro

Flutter/Dart Android app: ghost-ball aiming, direct shots and 1/2/3-cushion
bank shots for 8 Ball Pool, using the mirror-table (reflection) method.

## Status (read this first)
Written without access to a Flutter SDK, so **it has not been compiled, run
or tested on a device, and `flutter test` has not been executed**. The
mirror-reflection algorithm was checked separately in a Python prototype and
the test inputs were chosen from valid routes found there. Expect to fix a few
compile errors on first build. Not claimed complete until `flutter test` and
a device run pass.

## Structure
- `lib/engine/` pure-Dart calculation module (no Flutter imports)
  - `geometry.dart` Vec2, table spec, walls, pockets, coordinate conversion
  - `shot_engine.dart` ghost ball, unfolding/reflection, routes, obstacles
  - `spin.dart` heuristic spin/power estimates (kept separate from geometry)
- `lib/state/app_state.dart` state, settings, local storage (shared_preferences)
- `lib/ui/` table view (draggable balls), planner/bank screen, other screens
- `test/engine_test.dart` unit tests: direct, 1-, 2-, 3-cushion, obstacles

## Run
1. Install Flutter and Android SDK.
2. `./setup.sh` (creates `../bank_shot_pro_app` with the Android folder and
   copies the sources in, then runs `flutter pub get` and `flutter test`).
3. `cd ../bank_shot_pro_app && flutter run`

## Signed release APK
```
keytool -genkey -v -keystore ~/bankshot-key.jks -keyalg RSA -keysize 2048 \
  -validity 10000 -alias bankshot
```
Create `android/key.properties`:
```
storePassword=...
keyPassword=...
keyAlias=bankshot
storeFile=/home/you/bankshot-key.jks
```
In `android/app/build.gradle(.kts)` load `key.properties`, add a
`signingConfigs.release` block using it, and set
`buildTypes.release.signingConfig = signingConfigs.release`
(see https://docs.flutter.dev/deployment/android#sign-the-app). Then:
```
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`. Keep the keystore safe.

## Model and limits
- Units cm, origin top-left of the playing surface, +y down. Table 2:1.
- Ball centres rebound on walls inset by one ball radius.
- Object-ball banks only (cue ball aims at the ghost ball). Cue-ball kick
  shots are not implemented.
- Pocket entry uses a simple mouth-tolerance test, not real pocket jaw shapes.
- Obstruction: any ball centre closer than 2 radii to a travelling ball's path.
- Spin/power numbers are rule-of-thumb estimates; drawn paths are pure geometry.
