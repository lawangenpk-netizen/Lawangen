import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Cue-ball face: drag the dot. Right = right spin, up = topspin.
class SpinPad extends StatelessWidget {
  final double side, vertical;
  final void Function(double side, double vertical) onChanged;
  const SpinPad(
      {super.key,
      required this.side,
      required this.vertical,
      required this.onChanged});

  void _update(Offset p, double size) {
    final c = size / 2;
    var dx = (p.dx - c) / c, dy = -(p.dy - c) / c;
    final l = math.sqrt(dx * dx + dy * dy);
    if (l > 1) {
      dx /= l;
      dy /= l;
    }
    onChanged(dx, dy);
  }

  @override
  Widget build(BuildContext context) {
    const size = 130.0;
    return GestureDetector(
      onPanDown: (d) => _update(d.localPosition, size),
      onPanUpdate: (d) => _update(d.localPosition, size),
      onDoubleTap: () => onChanged(0, 0),
      child: CustomPaint(
          size: const Size(size, size),
          painter: _PadPainter(side, vertical)),
    );
  }
}

class _PadPainter extends CustomPainter {
  final double side, vertical;
  _PadPainter(this.side, this.vertical);
  @override
  bool shouldRepaint(covariant _PadPainter o) =>
      o.side != side || o.vertical != vertical;
  @override
  void paint(Canvas canvas, Size s) {
    final c = Offset(s.width / 2, s.height / 2);
    final r = s.width / 2 - 2;
    canvas.drawCircle(c, r, Paint()..color = Colors.white);
    final line = Paint()
      ..color = Colors.black26
      ..strokeWidth = 1;
    canvas.drawLine(Offset(c.dx - r, c.dy), Offset(c.dx + r, c.dy), line);
    canvas.drawLine(Offset(c.dx, c.dy - r), Offset(c.dx, c.dy + r), line);
    canvas.drawCircle(c, r * 0.5, Paint()
      ..style = PaintingStyle.stroke
      ..color = Colors.black26);
    canvas.drawCircle(Offset(c.dx + side * r, c.dy - vertical * r), 8,
        Paint()..color = Colors.redAccent);
  }
}
