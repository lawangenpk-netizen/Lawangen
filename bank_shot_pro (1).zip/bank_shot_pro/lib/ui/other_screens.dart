import 'package:flutter/material.dart';
import '../state/app_state.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    Widget tile(IconData i, String t, String sub, VoidCallback f) => Card(
          child: ListTile(
              leading: Icon(i, color: Colors.greenAccent, size: 30),
              title: Text(t),
              subtitle: Text(sub),
              trailing: const Icon(Icons.chevron_right),
              onTap: f),
        );
    return Scaffold(
      appBar: AppBar(title: const Text('Bank Shot Pro')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('8 Ball Pool aiming calculator',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        const Text(
            'Place the balls, pick a pocket, and get the ghost ball, aim line and cushion routes.',
            style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        tile(Icons.sports_bar_outlined, 'Shot planner',
            'Direct shots, ghost ball, obstacles', () => appState.setTab(1)),
        tile(Icons.call_split, 'Bank shot calculator',
            '1-, 2- and 3-cushion routes', () => appState.setTab(2)),
        tile(Icons.bookmarks_outlined, 'Saved shots', 'Reopen your setups',
            () => appState.setTab(3)),
        tile(Icons.tune, 'Settings', 'Table size, ball size, tolerances',
            () => appState.setTab(4)),
        tile(Icons.help_outline, 'Help & instructions', 'How it works',
            () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const HelpScreen()))),
      ]),
    );
  }
}

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => Scaffold(
          appBar: AppBar(title: const Text('Saved shots')),
          body: appState.saved.isEmpty
              ? const Center(
                  child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                          'No saved shots yet. Use the bookmark button in the planner or bank calculator.',
                          textAlign: TextAlign.center)))
              : ListView(children: [
                  for (final s in appState.saved)
                    Dismissible(
                      key: ValueKey(s.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                          color: Colors.redAccent,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 16),
                          child: const Icon(Icons.delete)),
                      onDismissed: (_) => appState.deleteShot(s.id),
                      child: ListTile(
                        leading: Icon(s.bank ? Icons.call_split : Icons.sports_bar_outlined),
                        title: Text(s.name),
                        subtitle: Text(
                            '${s.settings.tableLength.toStringAsFixed(0)} cm table · pocket ${s.pocketIndex + 1} · ${s.obstacles.length} obstacle(s) · ${s.createdAt.toLocal().toString().substring(0, 16)}'),
                        onTap: () => appState.openShot(s),
                        trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => appState.deleteShot(s.id)),
                      ),
                    ),
                ]),
        ),
      );
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) {
          final s = appState.settings;
          Widget slider(String label, double v, double min, double max,
                  AppSettings Function(double) f, {int digits = 1}) =>
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('$label: ${v.toStringAsFixed(digits)}'),
                Slider(
                    value: v.clamp(min, max).toDouble(),
                    min: min,
                    max: max,
                    onChanged: (x) => appState.updateSettings(f(x))),
              ]);
          return Scaffold(
            appBar: AppBar(title: const Text('Settings')),
            body: ListView(padding: const EdgeInsets.all(16), children: [
              slider('Table length (cm), width = half', s.tableLength, 200, 280,
                  (x) => s.copyWith(tableLength: x), digits: 0),
              slider('Ball radius (cm)', s.ballRadius, 2.0, 4.0,
                  (x) => s.copyWith(ballRadius: x), digits: 2),
              slider('Pocket mouth tolerance (cm)', s.pocketMouth, 4, 12,
                  (x) => s.copyWith(pocketMouth: x)),
              slider('Maximum cut angle (°)', s.maxCutDeg, 45, 89,
                  (x) => s.copyWith(maxCutDeg: x), digits: 0),
              slider('Spin estimate sensitivity', s.spinSensitivity, 0.2, 2.0,
                  (x) => s.copyWith(spinSensitivity: x), digits: 2),
              SwitchListTile(
                  title: const Text('Show alternative routes on table'),
                  value: s.showAltRoutes,
                  onChanged: (v) =>
                      appState.updateSettings(s.copyWith(showAltRoutes: v))),
              OutlinedButton(
                  onPressed: () =>
                      appState.updateSettings(const AppSettings()),
                  child: const Text('Restore defaults')),
              const SizedBox(height: 8),
              const Text(
                  'Match the table length and ball size to the game for best accuracy. 8 Ball Pool tables are not exactly regulation size, so check your aim in practice.',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
            ]),
          );
        },
      );
}

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Help & instructions')),
        body: ListView(padding: const EdgeInsets.all(16), children: const [
          Text('Using the planner',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(
              '1. Drag the white cue ball and the yellow object ball to match your game.\n'
              '2. Tap a pocket (or use the chips) to choose the target.\n'
              '3. Pick how many cushions to allow. Routes are listed best first; tap one to select it.\n'
              '4. Aim the cue ball along the white line at the dashed ghost ball.\n'
              '5. Use "Obstacle" to add other balls; blocked routes are flagged in red and an alternative is suggested.'),
          SizedBox(height: 16),
          Text('How it works',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(
              'Bank shots use the mirror-table method: the pocket is reflected across the cushions, a straight line to that image gives the cushion contact points, and the ghost ball sits two ball radii behind the object ball on the first leg. All routes are computed live from ball positions; nothing is hard-coded.'),
          SizedBox(height: 16),
          Text('Limits',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(
              'Paths are geometric (perfect reflections, no cushion compression). Spin and power figures are rough estimates and do not move the drawn lines. Only the object ball banks; kick shots with the cue ball are not included. Always verify in practice.'),
        ]),
      );
}
