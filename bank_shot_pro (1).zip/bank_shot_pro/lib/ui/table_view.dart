import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../engine/engine.dart';
import '../state/app_state.dart';

/// Interactive top-down table: drag balls, tap a pocket to select it.
class PoolTableView extends StatelessWidget {
  final AppState state;
  final List<ShotRoute> routes;
  final ShotRoute? selected;
  const PoolTableView(
      {super.key,
      required this.state,
      required this.routes,
      required this.selected});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final table = state.table;
      final tf = TableTransform(table, c.maxWidth);
      return _Interactive(
        state: state,
        tf: tf,
        child: CustomPaint(
          size: Size(c.maxWidth, tf.heightPx),
          painter: _TablePainter(state, routes, selected),
        ),
      );
    });
  }
}

class _Interactive extends StatefulWidget {
  final AppState state;
  final TableTransform tf;
  final Widget child;
  const _Interactive(
      {required this.state, required this.tf, required this.child});
  @override
  State<_Interactive> createState() => _InteractiveState();
}

class _InteractiveState extends State<_Interactive> {
  String? _drag;
  Vec2 _grab = const Vec2(0, 0);

  List<String> get _ids => [
        'cue',
        'obj',
        for (var i = 0; i < widget.state.obstacles.length; i++) 'o$i'
      ];

  @override
  Widget build(BuildContext context) {
    final tf = widget.tf;
    final s = widget.state;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (d) {
        final p = tf.toTable(d.localPosition.dx, d.localPosition.dy);
        final tol = math.max(s.table.ballRadius * 2.2, 30 / tf.scale);
        String? best;
        var bestD = tol;
        for (final id in _ids) {
          final dist = s.ballPos(id).distanceTo(p);
          if (dist < bestD) {
            bestD = dist;
            best = id;
          }
        }
        _drag = best;
        if (best != null) _grab = s.ballPos(best) - p;
      },
      onPanUpdate: (d) {
        final id = _drag;
        if (id == null) return;
        final p = tf.toTable(d.localPosition.dx, d.localPosition.dy);
        s.moveBall(id, p + _grab);
      },
      onPanEnd: (_) => _drag = null,
      onPanCancel: () => _drag = null,
      onTapUp: (d) {
        final p = tf.toTable(d.localPosition.dx, d.localPosition.dy);
        final tol = math.max(s.table.pocketMouth, 26 / tf.scale);
        final pockets = s.table.pockets;
        for (var i = 0; i < pockets.length; i++) {
          if (pockets[i].center.distanceTo(p) < tol) {
            s.setPocket(i);
            return;
          }
        }
      },
      child: widget.child,
    );
  }
}

class _TablePainter extends CustomPainter {
  final AppState s;
  final List<ShotRoute> routes;
  final ShotRoute? sel;
  _TablePainter(this.s, this.routes, this.sel);

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;

  void _dashed(Canvas c, Offset a, Offset b, Paint p,
      {double dash = 8, double gap = 6}) {
    final total = (b - a).distance;
    if (total < 1) return;
    final dir = (b - a) / total;
    var d = 0.0;
    while (d < total) {
      final e = math.min(d + dash, total);
      c.drawLine(a + dir * d, a + dir * e, p);
      d += dash + gap;
    }
  }

  void _dashedCircle(Canvas c, Offset center, double rad, Paint p) {
    final path = Path()..addOval(Rect.fromCircle(center: center, radius: rad));
    for (final m in path.computeMetrics()) {
      var d = 0.0;
      while (d < m.length) {
        c.drawPath(m.extractPath(d, math.min(d + 5, m.length)), p);
        d += 9;
      }
    }
  }

  void _text(Canvas c, String t, Offset center,
      {double size = 12, Color color = Colors.white}) {
    final tp = TextPainter(
        text: TextSpan(
            text: t,
            style: TextStyle(
                color: color, fontSize: size, fontWeight: FontWeight.bold)),
        textDirection: TextDirection.ltr)
      ..layout();
    tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final table = s.table;
    final tf = TableTransform(table, size.width);
    final sc = tf.scale;
    Offset o(Vec2 v) {
      final p = tf.toScreen(v);
      return Offset(p.x, p.y);
    }

    final rad = table.ballRadius * sc;

    // Rail + felt
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(0, 0, size.width, tf.heightPx), Radius.circular(sc * 6)),
        Paint()..color = const Color(0xFF4A2F18));
    final felt =
        Rect.fromPoints(o(const Vec2(0, 0)), o(Vec2(table.length, table.width)));
    canvas.drawRect(felt, Paint()..color = const Color(0xFF0E6B3C));
    canvas.drawRect(
        felt,
        Paint()
          ..style = PaintingStyle.stroke
          ..color = const Color(0xFF0A4D2B)
          ..strokeWidth = sc * 1.5);
    // Diamonds
    final dm = Paint()..color = const Color(0xFFE8D9B0);
    for (var i = 1; i < 8; i++) {
      if (i == 4) continue;
      final x = table.length * i / 8;
      canvas.drawCircle(o(Vec2(x, -5)), sc * 0.9, dm);
      canvas.drawCircle(o(Vec2(x, table.width + 5)), sc * 0.9, dm);
    }
    for (var i = 1; i < 4; i++) {
      final y = table.width * i / 4;
      canvas.drawCircle(o(Vec2(-5, y)), sc * 0.9, dm);
      canvas.drawCircle(o(Vec2(table.length + 5, y)), sc * 0.9, dm);
    }
    // Pockets
    final pockets = table.pockets;
    for (var i = 0; i < pockets.length; i++) {
      final c = o(pockets[i].center);
      canvas.drawCircle(c, table.pocketMouth * sc * 0.85,
          Paint()..color = Colors.black);
      if (i == s.pocketIndex) {
        canvas.drawCircle(
            c,
            table.pocketMouth * sc * 1.05,
            Paint()
              ..style = PaintingStyle.stroke
              ..color = Colors.amberAccent
              ..strokeWidth = 3);
      }
    }

    // Alternative routes (faint)
    if (s.settings.showAltRoutes) {
      final faint = Paint()
        ..color = Colors.white24
        ..strokeWidth = 1.2
        ..style = PaintingStyle.stroke;
      for (final r in routes) {
        if (identical(r, sel)) continue;
        final pts = r.objectPath.map(o).toList();
        for (var i = 0; i + 1 < pts.length; i++) {
          canvas.drawLine(pts[i], pts[i + 1], faint);
        }
      }
    }

    // Selected route
    final blocked = sel?.blockedBy;
    if (sel != null) {
      final r = sel!;
      final cuePaint = Paint()
        ..color = r.blockedLeg == 'cue' ? Colors.redAccent : Colors.white
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(o(s.cue), o(r.ghost), cuePaint);
      _dashedCircle(
          canvas,
          o(r.ghost),
          rad,
          Paint()
            ..style = PaintingStyle.stroke
            ..color = Colors.white
            ..strokeWidth = 1.8);
      final pts = r.objectPath.map(o).toList();
      final objCol = r.blockedLeg == 'object' ? Colors.redAccent : Colors.amber;
      for (var i = 0; i + 1 < pts.length; i++) {
        if (i == 0) {
          canvas.drawLine(
              pts[i],
              pts[i + 1],
              Paint()
                ..color = objCol
                ..strokeWidth = 2.6
                ..strokeCap = StrokeCap.round);
        } else {
          _dashed(
              canvas,
              pts[i],
              pts[i + 1],
              Paint()
                ..color = Colors.cyanAccent
                ..strokeWidth = 2.4
                ..strokeCap = StrokeCap.round);
        }
      }
      for (var i = 0; i < r.contactPoints.length; i++) {
        final c = o(r.contactPoints[i]);
        canvas.drawCircle(c, rad * 0.55, Paint()..color = Colors.cyanAccent);
        _text(canvas, '${i + 1}', c, size: rad * 0.8, color: Colors.black);
      }
    }

    // Balls
    void ball(Vec2 p, Color col, String label, {bool danger = false}) {
      final c = o(p);
      canvas.drawCircle(c + Offset(rad * 0.15, rad * 0.2), rad,
          Paint()..color = Colors.black26);
      canvas.drawCircle(
          c,
          rad,
          Paint()
            ..shader = RadialGradient(
                    center: const Alignment(-0.35, -0.4),
                    colors: [Colors.white.withOpacity(0.9), col, col])
                .createShader(Rect.fromCircle(center: c, radius: rad)));
      if (label.isNotEmpty) _text(canvas, label, c, size: rad * 1.0, color: Colors.black);
      if (danger) {
        canvas.drawCircle(
            c,
            rad * 1.35,
            Paint()
              ..style = PaintingStyle.stroke
              ..color = Colors.redAccent
              ..strokeWidth = 3);
      }
    }

    for (var i = 0; i < s.obstacles.length; i++) {
      ball(s.obstacles[i], const Color(0xFF3B6FD4), '${i + 1}',
          danger: blocked == 'o$i');
    }
    ball(s.object, const Color(0xFFF2B01E), '', danger: blocked == 'obj');
    ball(s.cue, Colors.white, '');
  }
}
