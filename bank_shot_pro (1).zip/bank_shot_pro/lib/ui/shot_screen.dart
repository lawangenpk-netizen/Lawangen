import 'package:flutter/material.dart';
import '../engine/engine.dart';
import '../state/app_state.dart';
import 'spin_pad.dart';
import 'table_view.dart';

/// Shared by the Shot Planner (bank: false) and Bank Shot Calculator
/// (bank: true) screens.
class ShotScreen extends StatelessWidget {
  final bool bank;
  const ShotScreen({super.key, required this.bank});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: appState, builder: (c, _) => _build(c));

  Widget _build(BuildContext context) {
    final s = appState;
    final maxC = bank ? s.bankMax : s.plannerMax;
    final routes = s.routesFor(maxC);
    var idx = routes.indexWhere((r) => r.key == s.selectedKey);
    if (idx < 0 && routes.isNotEmpty) idx = 0;
    final sel = idx >= 0 ? routes[idx] : null;
    final pockets = s.table.pockets;

    return Scaffold(
      appBar: AppBar(
          title: Text(bank ? 'Bank Shot Calculator' : 'Shot Planner'),
          actions: [
            IconButton(
                tooltip: 'Save shot',
                icon: const Icon(Icons.bookmark_add_outlined),
                onPressed: () => _save(context)),
          ]),
      body: ListView(padding: const EdgeInsets.all(8), children: [
        PoolTableView(state: s, routes: routes, selected: sel),
        const SizedBox(height: 4),
        const Text(
            'Drag balls to move them. Tap a pocket to target it.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 12)),
        const SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 0, children: [
          for (var i = 0; i < pockets.length; i++)
            ChoiceChip(
              label: Text(pockets[i].name),
              selected: s.pocketIndex == i,
              onSelected: (_) => s.setPocket(i),
            ),
        ]),
        const SizedBox(height: 8),
        SegmentedButton<int>(
          segments: [
            if (!bank) const ButtonSegment(value: 0, label: Text('Direct')),
            const ButtonSegment(value: 1, label: Text('≤1 cushion')),
            const ButtonSegment(value: 2, label: Text('≤2')),
            const ButtonSegment(value: 3, label: Text('≤3')),
          ],
          selected: {maxC < (bank ? 1 : 0) ? (bank ? 1 : 0) : maxC},
          onSelectionChanged: (v) => s.setMax(bank, v.first),
        ),
        Row(children: [
          TextButton.icon(
              onPressed: s.addObstacle,
              icon: const Icon(Icons.add_circle_outline),
              label: const Text('Obstacle')),
          TextButton.icon(
              onPressed: s.obstacles.isEmpty ? null : s.removeObstacle,
              icon: const Icon(Icons.remove_circle_outline),
              label: const Text('Remove')),
          const Spacer(),
          TextButton.icon(
              onPressed: s.resetLayout,
              icon: const Icon(Icons.restart_alt),
              label: const Text('Reset')),
        ]),
        _status(s, sel),
        const SizedBox(height: 8),
        Text('Routes to ${pockets[s.pocketIndex].name} (${routes.length})',
            style: Theme.of(context).textTheme.titleMedium),
        if (routes.isEmpty)
          const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                  'No valid route with this cushion count. Try allowing more cushions or move a ball.')),
        for (var i = 0; i < routes.length; i++) _routeTile(s, routes[i], i == idx),
        if (sel != null) _details(s, sel),
        if (sel != null) _spinCard(s, sel),
      ]),
    );
  }

  Widget _status(AppState s, ShotRoute? sel) {
    if (sel == null) return const SizedBox.shrink();
    if (sel.playable) {
      return _banner(Colors.green, Icons.check_circle,
          'Clear shot: no obstruction detected on this route.');
    }
    final reason = sel.blockedBy != null
        ? 'Blocked by ${s.ballName(sel.blockedBy!)} on the '
            '${sel.blockedLeg == 'cue' ? 'cue-ball' : 'object-ball'} path.'
        : sel.problem!;
    final alts = s.routesFor(3).where((r) => r.playable).toList();
    return Column(children: [
      _banner(Colors.redAccent, Icons.warning_amber, reason),
      if (alts.isNotEmpty)
        Card(
          child: ListTile(
            leading: const Icon(Icons.lightbulb_outline, color: Colors.amber),
            title: Text('Try: ${alts.first.label}'),
            subtitle: Text(
                '${alts.first.totalDistance.toStringAsFixed(0)} cm, cut ${alts.first.cutAngleDeg.toStringAsFixed(0)}°'),
            trailing: TextButton(
                onPressed: () {
                  final n = alts.first.cushions;
                  if (n > s.plannerMax) s.setMax(false, n);
                  if (n > s.bankMax) s.setMax(true, n);
                  s.selectRoute(alts.first.key);
                },
                child: const Text('Use')),
          ),
        )
      else
        const Padding(
            padding: EdgeInsets.all(8),
            child: Text('No unobstructed route found up to 3 cushions.')),
    ]);
  }

  Widget _banner(Color c, IconData i, String t) => Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: c.withOpacity(0.2),
            border: Border.all(color: c),
            borderRadius: BorderRadius.circular(10)),
        child: Row(children: [
          Icon(i, color: c),
          const SizedBox(width: 8),
          Expanded(child: Text(t)),
        ]),
      );

  Widget _routeTile(AppState s, ShotRoute r, bool selected) {
    final status = r.blockedBy != null
        ? 'BLOCKED by ${s.ballName(r.blockedBy!)}'
        : (r.problem ?? 'clear');
    return Card(
      color: selected ? const Color(0xFF1E3B2B) : null,
      child: ListTile(
        dense: true,
        leading: Icon(r.playable ? Icons.check_circle : Icons.block,
            color: r.playable ? Colors.greenAccent : Colors.redAccent),
        title: Text(r.label),
        subtitle: Text(
            '${r.totalDistance.toStringAsFixed(0)} cm · cut ${r.cutAngleDeg.toStringAsFixed(0)}° · $status'),
        onTap: () => s.selectRoute(r.key),
      ),
    );
  }

  Widget _details(AppState s, ShotRoute r) {
    final pocket = s.table.pockets[r.pocketIndex].name;
    final rows = <String>[
      'Aim direction (cue ball): ${bearingDeg(r.cueDirection).toStringAsFixed(1)}°  (0° = right, 90° = down)',
      'Ghost-ball position: ${r.ghost}',
      'Contact point on object ball: ${r.objectPath[0] - r.firstLegDirection * s.table.ballRadius}',
      'Cut angle: ${r.cutAngleDeg.toStringAsFixed(1)}°',
      'Cue ball travel: ${r.cueDistance.toStringAsFixed(1)} cm',
      'Object ball travel: ${r.objectDistance.toStringAsFixed(1)} cm',
      'Total distance: ${r.totalDistance.toStringAsFixed(1)} cm',
      for (var i = 0; i < r.contactPoints.length; i++)
        '${_ord(i + 1)} cushion contact (${r.walls[i].label}): ${r.contactPoints[i]}',
      'Final target direction: ${bearingDeg(r.finalDirection).toStringAsFixed(1)}° into $pocket pocket',
    ];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Selected: ${r.label}',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          for (final t in rows)
            Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Text(t)),
          const SizedBox(height: 6),
          const Text(
              'Legend: white = cue path, dashed circle = ghost ball, yellow = object path, cyan dashed = cushion rebounds. Coordinates are cm from the top-left corner.',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      ),
    );
  }

  static String _ord(int n) => n == 1 ? '1st' : n == 2 ? '2nd' : '3rd';

  Widget _spinCard(AppState s, ShotRoute r) {
    final e = estimateSpin(r, s.spin, sensitivity: s.settings.spinSensitivity);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Spin & power (estimates only)',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(children: [
            SpinPad(
                side: s.spin.side,
                vertical: s.spin.vertical,
                onChanged: (a, b) =>
                    s.setSpin(s.spin.copyWith(side: a, vertical: b))),
            const SizedBox(width: 12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_spinName(s.spin)),
              const SizedBox(height: 6),
              Text('Power ${(s.spin.power * 100).round()}%'),
              Slider(
                  value: s.spin.power,
                  onChanged: (v) => s.setSpin(s.spin.copyWith(power: v))),
              const Text('Double-tap pad to centre',
                  style: TextStyle(color: Colors.white54, fontSize: 11)),
            ])),
          ]),
          const Divider(),
          Text(
              'Cut-induced throw ≈ ${e.cutThrowDeg.toStringAsFixed(1)}° (≈ ${e.cutThrowOffsetCm.toStringAsFixed(1)} cm at end of first leg), carries the object ball toward the cue ball\'s direction of travel.'),
          const SizedBox(height: 4),
          Text(e.spinThrowDeg < 0.05
              ? 'Spin-induced throw: none (no side spin).'
              : 'Spin-induced throw ≈ ${e.spinThrowDeg.toStringAsFixed(1)}° to the ${e.spinThrowsLeft ? 'left' : 'right'} (≈ ${e.spinThrowOffsetCm.toStringAsFixed(1)} cm).'),
          const SizedBox(height: 4),
          Text(r.cushions == 0
              ? 'No cushion: no rebound uncertainty.'
              : 'Rebound angle uncertainty ≈ ±${e.reboundUncertaintyDeg.toStringAsFixed(1)}° per cushion (grows with power).'),
          const SizedBox(height: 4),
          Text(e.cueBallNote),
          const SizedBox(height: 6),
          const Text(
              'These are rule-of-thumb estimates, not a validated physics simulation. The drawn paths are pure geometry and do not change with spin or power.',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      ),
    );
  }

  String _spinName(SpinInput i) {
    final parts = <String>[];
    if (i.vertical > 0.15) parts.add('Topspin ${(i.vertical * 100).round()}%');
    if (i.vertical < -0.15) parts.add('Backspin ${(-i.vertical * 100).round()}%');
    if (i.side > 0.15) parts.add('Right ${(i.side * 100).round()}%');
    if (i.side < -0.15) parts.add('Left ${(-i.side * 100).round()}%');
    return parts.isEmpty ? 'Centre ball' : parts.join(' + ');
  }

  Future<void> _save(BuildContext context) async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
        context: context,
        builder: (c) => AlertDialog(
              title: const Text('Save shot'),
              content: TextField(
                  controller: ctrl,
                  autofocus: true,
                  decoration: const InputDecoration(hintText: 'Shot name')),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
                FilledButton(
                    onPressed: () => Navigator.pop(c, ctrl.text),
                    child: const Text('Save')),
              ],
            ));
    if (name != null) {
      await appState.saveShot(name, bank);
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Shot saved')));
      }
    }
  }
}
