import 'package:flutter/material.dart';
import 'state/app_state.dart';
import 'ui/other_screens.dart';
import 'ui/shot_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await appState.load();
  runApp(const BankShotApp());
}

class BankShotApp extends StatelessWidget {
  const BankShotApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Bank Shot Pro',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF1B8F52), brightness: Brightness.dark),
          scaffoldBackgroundColor: const Color(0xFF101414),
        ),
        home: const Shell(),
      );
}

class Shell extends StatelessWidget {
  const Shell({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => Scaffold(
          body: IndexedStack(index: appState.tab, children: const [
            HomeScreen(),
            ShotScreen(bank: false),
            ShotScreen(bank: true),
            SavedScreen(),
            SettingsScreen(),
          ]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: appState.tab,
            onDestinationSelected: appState.setTab,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.sports_bar_outlined), label: 'Planner'),
              NavigationDestination(icon: Icon(Icons.call_split), label: 'Bank'),
              NavigationDestination(icon: Icon(Icons.bookmarks_outlined), label: 'Saved'),
              NavigationDestination(icon: Icon(Icons.tune), label: 'Settings'),
            ],
          ),
        ),
      );
}
