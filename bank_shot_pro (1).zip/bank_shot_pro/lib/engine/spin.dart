import 'dart:math' as math;
import 'shot_engine.dart';

/// Player input. side: -1 left .. +1 right. vertical: -1 backspin .. +1
/// topspin. power: 0 (soft) .. 1 (hard).
class SpinInput {
  final double side, vertical, power;
  const SpinInput({this.side = 0, this.vertical = 0, this.power = 0.5});
  SpinInput copyWith({double? side, double? vertical, double? power}) =>
      SpinInput(
          side: side ?? this.side,
          vertical: vertical ?? this.vertical,
          power: power ?? this.power);
  Map<String, dynamic> toJson() =>
      {'side': side, 'vertical': vertical, 'power': power};
  factory SpinInput.fromJson(Map<String, dynamic> j) => SpinInput(
      side: (j['side'] as num).toDouble(),
      vertical: (j['vertical'] as num).toDouble(),
      power: (j['power'] as num).toDouble());
}

/// ROUGH HEURISTIC ESTIMATES. These are NOT a validated physics simulation
/// and are kept separate from the geometric route. Coefficients are typical
/// rule-of-thumb magnitudes; tune with [sensitivity] in Settings.
class SpinEstimate {
  /// Cut-induced throw (deg): object ball is carried toward the cue ball's
  /// direction of travel.
  final double cutThrowDeg;

  /// Spin-induced throw (deg, magnitude). Right English throws the object
  /// ball left; left English throws it right.
  final double spinThrowDeg;
  final bool spinThrowsLeft;

  /// Sideways error at the first cushion/pocket caused by throw (cm).
  final double cutThrowOffsetCm, spinThrowOffsetCm;

  /// Rebound angle uncertainty per cushion (deg), grows with power.
  final double reboundUncertaintyDeg;
  final String cueBallNote;
  const SpinEstimate({
    required this.cutThrowDeg,
    required this.spinThrowDeg,
    required this.spinThrowsLeft,
    required this.cutThrowOffsetCm,
    required this.spinThrowOffsetCm,
    required this.reboundUncertaintyDeg,
    required this.cueBallNote,
  });
}

SpinEstimate estimateSpin(ShotRoute route, SpinInput s,
    {double sensitivity = 1.0}) {
  final cut = route.cutAngleDeg * math.pi / 180;
  // Throw is larger on slow shots.
  final speedFactor = 1.2 - 0.6 * s.power;
  final cutThrow = 3.5 * math.sin(2 * cut).abs() * sensitivity * speedFactor;
  final spinThrow = 1.2 * s.side.abs() * sensitivity * speedFactor;
  final leg = route.objectPath[0].distanceTo(route.objectPath[1]);
  double off(double deg) => math.tan(deg * math.pi / 180) * leg;
  final rebound =
      route.cushions == 0 ? 0.0 : (0.5 + 2.5 * s.power) * sensitivity;
  String note;
  if (s.vertical > 0.15) {
    note = 'Topspin: cue ball follows the object ball after contact.';
  } else if (s.vertical < -0.15) {
    note = 'Backspin: cue ball draws back after contact.';
  } else {
    note = 'Centre ball: cue ball stops/rolls near the contact point.';
  }
  return SpinEstimate(
    cutThrowDeg: cutThrow,
    spinThrowDeg: spinThrow,
    spinThrowsLeft: s.side > 0,
    cutThrowOffsetCm: off(cutThrow),
    spinThrowOffsetCm: off(spinThrow),
    reboundUncertaintyDeg: rebound,
    cueBallNote: note,
  );
}
