import 'dart:math' as math;

/// Table coordinates: centimetres, origin = top-left corner of the playing
/// surface (cushion nose line), +x to the right, +y DOWN (same as screen).
class Vec2 {
  final double x, y;
  const Vec2(this.x, this.y);
  Vec2 operator +(Vec2 o) => Vec2(x + o.x, y + o.y);
  Vec2 operator -(Vec2 o) => Vec2(x - o.x, y - o.y);
  Vec2 operator *(double k) => Vec2(x * k, y * k);
  double get length => math.sqrt(x * x + y * y);
  Vec2 get unit {
    final l = length;
    return l < 1e-12 ? const Vec2(0, 0) : Vec2(x / l, y / l);
  }

  double dot(Vec2 o) => x * o.x + y * o.y;
  double distanceTo(Vec2 o) => (this - o).length;
  Map<String, dynamic> toJson() => {'x': x, 'y': y};
  factory Vec2.fromJson(Map<String, dynamic> j) =>
      Vec2((j['x'] as num).toDouble(), (j['y'] as num).toDouble());
  @override
  String toString() => '(${x.toStringAsFixed(1)}, ${y.toStringAsFixed(1)})';
}

/// Direction as a screen bearing in degrees: 0 = right, 90 = down (clockwise).
double bearingDeg(Vec2 d) => (math.atan2(d.y, d.x) * 180 / math.pi + 360) % 360;

double distPointSegment(Vec2 p, Vec2 a, Vec2 b) {
  final ab = b - a;
  final l2 = ab.dot(ab);
  if (l2 < 1e-12) return p.distanceTo(a);
  final t = ((p - a).dot(ab) / l2).clamp(0.0, 1.0).toDouble();
  return p.distanceTo(a + ab * t);
}

enum Wall { left, right, top, bottom }

extension WallInfo on Wall {
  String get label => switch (this) {
        Wall.left => 'Left',
        Wall.right => 'Right',
        Wall.top => 'Top',
        Wall.bottom => 'Bottom',
      };
  bool get isVertical => this == Wall.left || this == Wall.right;
}

class Pocket {
  final String name;
  final Vec2 center;
  const Pocket(this.name, this.center);
}

class TableSpec {
  /// Playing surface length in cm; width is always length / 2.
  final double length;
  final double ballRadius;

  /// Max distance (cm) from pocket centre at which a ball crossing the
  /// cushion line still drops into the pocket.
  final double pocketMouth;
  const TableSpec(
      {this.length = 254.0, this.ballRadius = 2.85, this.pocketMouth = 7.5});

  double get width => length / 2;

  List<Pocket> get pockets => [
        Pocket('Top-left', const Vec2(0, 0)),
        Pocket('Top-side', Vec2(length / 2, 0)),
        Pocket('Top-right', Vec2(length, 0)),
        Pocket('Bottom-left', Vec2(0, width)),
        Pocket('Bottom-side', Vec2(length / 2, width)),
        Pocket('Bottom-right', Vec2(length, width)),
      ];

  /// Coordinate of the wall plane on which a ball CENTRE rebounds.
  double wallCoord(Wall w) => switch (w) {
        Wall.left => ballRadius,
        Wall.right => length - ballRadius,
        Wall.top => ballRadius,
        Wall.bottom => width - ballRadius,
      };

  Vec2 reflect(Vec2 p, Wall w) {
    final c = wallCoord(w);
    return switch (w) {
      Wall.left || Wall.right => Vec2(2 * c - p.x, p.y),
      Wall.top || Wall.bottom => Vec2(p.x, 2 * c - p.y),
    };
  }

  bool containsCenter(Vec2 p, {double eps = 1e-6}) =>
      p.x >= ballRadius - eps &&
      p.x <= length - ballRadius + eps &&
      p.y >= ballRadius - eps &&
      p.y <= width - ballRadius + eps;

  Vec2 clampCenter(Vec2 p) => Vec2(
        p.x.clamp(ballRadius, length - ballRadius).toDouble(),
        p.y.clamp(ballRadius, width - ballRadius).toDouble(),
      );
}

/// Table (cm) <-> pixel conversion, including a 10 cm wooden rail around
/// the playing surface.
class TableTransform {
  static const double railCm = 10;
  final TableSpec table;
  final double widthPx;
  const TableTransform(this.table, this.widthPx);
  double get scale => widthPx / (table.length + 2 * railCm);
  double get heightPx => (table.width + 2 * railCm) * scale;
  Vec2 toScreen(Vec2 t) =>
      Vec2((t.x + railCm) * scale, (t.y + railCm) * scale);
  Vec2 toTable(double px, double py) =>
      Vec2(px / scale - railCm, py / scale - railCm);
}
