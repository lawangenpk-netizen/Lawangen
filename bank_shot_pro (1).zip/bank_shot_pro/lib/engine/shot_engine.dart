import 'dart:math' as math;
import 'geometry.dart';

class BallPos {
  final String id;
  final Vec2 pos;
  const BallPos(this.id, this.pos);
}

class ShotRoute {
  final int pocketIndex;
  final List<Wall> walls;

  /// Object-ball centre path: [object, contact1.., pocket].
  final List<Vec2> objectPath;
  final Vec2 ghost;
  final Vec2 cueDirection;
  final double cutAngleDeg, cueDistance, objectDistance;

  /// Geometric/practical problem (cut too thin, ghost off table...) or null.
  final String? problem;

  /// Id of the first ball blocking the shot, or null.
  final String? blockedBy;

  /// 'cue' (cue ball path) or 'object' (object ball path) when blocked.
  final String? blockedLeg;

  const ShotRoute({
    required this.pocketIndex,
    required this.walls,
    required this.objectPath,
    required this.ghost,
    required this.cueDirection,
    required this.cutAngleDeg,
    required this.cueDistance,
    required this.objectDistance,
    this.problem,
    this.blockedBy,
    this.blockedLeg,
  });

  int get cushions => walls.length;
  double get totalDistance => cueDistance + objectDistance;
  bool get playable => problem == null && blockedBy == null;
  List<Vec2> get contactPoints => objectPath.sublist(1, objectPath.length - 1);
  Vec2 get finalDirection =>
      (objectPath.last - objectPath[objectPath.length - 2]).unit;
  Vec2 get firstLegDirection => (objectPath[1] - objectPath[0]).unit;
  String get key => walls.map((w) => w.name).join(',');
  String get label => walls.isEmpty
      ? 'Direct'
      : '${walls.length}-cushion (${walls.map((w) => w.label).join(' > ')})';
}

class ShotEngine {
  final TableSpec table;
  const ShotEngine(this.table);

  /// Mirror-table method. Returns [source, p1..pn, target] or null when the
  /// unfolded straight line does not produce valid cushion hits.
  List<Vec2>? unfold(Vec2 source, Vec2 target, List<Wall> walls) {
    final n = walls.length;
    final images = List<Vec2>.filled(n + 1, target);
    for (var k = n - 1; k >= 0; k--) {
      images[k] = table.reflect(images[k + 1], walls[k]);
    }
    final pts = <Vec2>[source];
    var a = source;
    for (var i = 0; i < n; i++) {
      final w = walls[i];
      final b = images[i];
      final c = table.wallCoord(w);
      final d = w.isVertical ? b.x - a.x : b.y - a.y;
      if (d.abs() < 1e-12) return null;
      final t = ((w.isVertical ? c - a.x : c - a.y)) / d;
      if (t <= 1e-9 || t >= 1 - 1e-9) return null;
      final p = Vec2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
      final other = w.isVertical ? p.y : p.x;
      final lo = table.ballRadius;
      final hi = (w.isVertical ? table.width : table.length) - table.ballRadius;
      if (other < lo - 1e-9 || other > hi + 1e-9) return null;
      pts.add(p);
      a = p;
    }
    pts.add(target);
    return pts;
  }

  /// True if the final leg a -> pocket leaves the ball-centre area within
  /// pocketMouth of the pocket centre.
  bool pocketReachable(Vec2 a, Vec2 pocket) {
    final dx = pocket.x - a.x, dy = pocket.y - a.y;
    final ts = <double>[];
    final r = table.ballRadius;
    if (dx < 0) ts.add((r - a.x) / dx);
    if (dx > 0) ts.add((table.length - r - a.x) / dx);
    if (dy < 0) ts.add((r - a.y) / dy);
    if (dy > 0) ts.add((table.width - r - a.y) / dy);
    final pos = ts.where((t) => t >= 0).toList();
    if (pos.isEmpty) return true;
    final t = pos.reduce(math.min);
    if (t >= 1) return true;
    final exit = Vec2(a.x + dx * t, a.y + dy * t);
    return exit.distanceTo(pocket) <= table.pocketMouth;
  }

  static List<List<Wall>> wallSequences(int n) {
    if (n == 0) return [<Wall>[]];
    final res = <List<Wall>>[];
    void build(List<Wall> cur) {
      if (cur.length == n) {
        res.add(List.of(cur));
        return;
      }
      for (final w in Wall.values) {
        if (cur.isNotEmpty && cur.last == w) continue;
        cur.add(w);
        build(cur);
        cur.removeLast();
      }
    }

    build([]);
    return res;
  }

  /// A ball travelling A->B is blocked by [ball] if centres come closer than 2r.
  bool _hits(Vec2 a, Vec2 b, Vec2 ball) =>
      distPointSegment(ball, a, b) < 2 * table.ballRadius - 1e-6;

  ShotRoute? computeRoute({
    required Vec2 cue,
    required Vec2 object,
    required List<BallPos> obstacles,
    required int pocketIndex,
    required List<Wall> walls,
    double maxCutDeg = 85,
  }) {
    final r = table.ballRadius;
    final pocket = table.pockets[pocketIndex].center;
    final path = unfold(object, pocket, walls);
    if (path == null) return null;
    if (!pocketReachable(path[path.length - 2], pocket)) return null;

    final dir1 = (path[1] - path[0]).unit;
    final ghost = object - dir1 * (2 * r);
    final toGhost = ghost - cue;
    final cueDist = toGhost.length;
    final cueDir = toGhost.unit;
    var cut = 0.0;
    if (cueDist > 1e-9) {
      cut = math.acos(cueDir.dot(dir1).clamp(-1.0, 1.0).toDouble()) *
          180 /
          math.pi;
    }
    var objDist = 0.0;
    for (var i = 0; i + 1 < path.length; i++) {
      objDist += path[i].distanceTo(path[i + 1]);
    }

    String? problem;
    if (cue.distanceTo(object) < 2 * r - 1e-6) {
      problem = 'Cue ball overlaps the object ball';
    } else if (!table.containsCenter(ghost)) {
      problem = 'Ghost ball would be off the table';
    } else if (cut > maxCutDeg) {
      problem = 'Cut angle too thin (${cut.toStringAsFixed(0)}°)';
    }

    String? blockedBy, blockedLeg;
    // Cue-ball leg: cue -> ghost. The object ball must not be touched early.
    if (_hits(cue, ghost, object)) {
      blockedBy = 'obj';
      blockedLeg = 'cue';
    }
    for (final o in obstacles) {
      if (blockedBy != null) break;
      if (_hits(cue, ghost, o.pos)) {
        blockedBy = o.id;
        blockedLeg = 'cue';
      }
    }
    // Object-ball legs (the cue ball has moved away by then).
    for (var i = 0; i + 1 < path.length && blockedBy == null; i++) {
      for (final o in obstacles) {
        if (_hits(path[i], path[i + 1], o.pos)) {
          blockedBy = o.id;
          blockedLeg = 'object';
          break;
        }
      }
    }

    return ShotRoute(
      pocketIndex: pocketIndex,
      walls: walls,
      objectPath: path,
      ghost: ghost,
      cueDirection: cueDir,
      cutAngleDeg: cut,
      cueDistance: cueDist,
      objectDistance: objDist,
      problem: problem,
      blockedBy: blockedBy,
      blockedLeg: blockedLeg,
    );
  }

  /// All routes (0..maxCushions cushions) for one pocket, best first.
  List<ShotRoute> computeRoutes({
    required Vec2 cue,
    required Vec2 object,
    required List<BallPos> obstacles,
    required int pocketIndex,
    int maxCushions = 3,
    double maxCutDeg = 85,
  }) {
    final out = <ShotRoute>[];
    for (var n = 0; n <= maxCushions; n++) {
      for (final seq in wallSequences(n)) {
        final r = computeRoute(
            cue: cue,
            object: object,
            obstacles: obstacles,
            pocketIndex: pocketIndex,
            walls: seq,
            maxCutDeg: maxCutDeg);
        if (r != null) out.add(r);
      }
    }
    out.sort((a, b) {
      if (a.playable != b.playable) return a.playable ? -1 : 1;
      if (a.cushions != b.cushions) return a.cushions - b.cushions;
      return a.totalDistance.compareTo(b.totalDistance);
    });
    return out;
  }
}
