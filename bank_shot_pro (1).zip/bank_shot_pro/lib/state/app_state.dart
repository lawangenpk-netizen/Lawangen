import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../engine/engine.dart';

class AppSettings {
  final double tableLength, ballRadius, pocketMouth, maxCutDeg, spinSensitivity;
  final bool showAltRoutes;
  const AppSettings({
    this.tableLength = 254,
    this.ballRadius = 2.85,
    this.pocketMouth = 7.5,
    this.maxCutDeg = 85,
    this.spinSensitivity = 1.0,
    this.showAltRoutes = true,
  });
  AppSettings copyWith({
    double? tableLength,
    double? ballRadius,
    double? pocketMouth,
    double? maxCutDeg,
    double? spinSensitivity,
    bool? showAltRoutes,
  }) =>
      AppSettings(
        tableLength: tableLength ?? this.tableLength,
        ballRadius: ballRadius ?? this.ballRadius,
        pocketMouth: pocketMouth ?? this.pocketMouth,
        maxCutDeg: maxCutDeg ?? this.maxCutDeg,
        spinSensitivity: spinSensitivity ?? this.spinSensitivity,
        showAltRoutes: showAltRoutes ?? this.showAltRoutes,
      );
  Map<String, dynamic> toJson() => {
        'tableLength': tableLength,
        'ballRadius': ballRadius,
        'pocketMouth': pocketMouth,
        'maxCutDeg': maxCutDeg,
        'spinSensitivity': spinSensitivity,
        'showAltRoutes': showAltRoutes,
      };
  factory AppSettings.fromJson(Map<String, dynamic> j) {
    const d = AppSettings();
    double n(String k, double def) => (j[k] as num?)?.toDouble() ?? def;
    return AppSettings(
      tableLength: n('tableLength', d.tableLength),
      ballRadius: n('ballRadius', d.ballRadius),
      pocketMouth: n('pocketMouth', d.pocketMouth),
      maxCutDeg: n('maxCutDeg', d.maxCutDeg),
      spinSensitivity: n('spinSensitivity', d.spinSensitivity),
      showAltRoutes: j['showAltRoutes'] as bool? ?? true,
    );
  }
}

class SavedShot {
  final String id, name;
  final DateTime createdAt;
  final Vec2 cue, object;
  final List<Vec2> obstacles;
  final int pocketIndex, maxCushions;
  final bool bank;
  final String? routeKey;
  final SpinInput spin;
  final AppSettings settings;
  const SavedShot({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.cue,
    required this.object,
    required this.obstacles,
    required this.pocketIndex,
    required this.maxCushions,
    required this.bank,
    required this.routeKey,
    required this.spin,
    required this.settings,
  });
  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'createdAt': createdAt.toIso8601String(),
        'cue': cue.toJson(),
        'object': object.toJson(),
        'obstacles': obstacles.map((o) => o.toJson()).toList(),
        'pocketIndex': pocketIndex,
        'maxCushions': maxCushions,
        'bank': bank,
        'routeKey': routeKey,
        'spin': spin.toJson(),
        'settings': settings.toJson(),
      };
  factory SavedShot.fromJson(Map<String, dynamic> j) => SavedShot(
        id: j['id'] as String,
        name: j['name'] as String,
        createdAt: DateTime.parse(j['createdAt'] as String),
        cue: Vec2.fromJson(j['cue'] as Map<String, dynamic>),
        object: Vec2.fromJson(j['object'] as Map<String, dynamic>),
        obstacles: (j['obstacles'] as List)
            .map((o) => Vec2.fromJson(o as Map<String, dynamic>))
            .toList(),
        pocketIndex: j['pocketIndex'] as int,
        maxCushions: j['maxCushions'] as int,
        bank: j['bank'] as bool,
        routeKey: j['routeKey'] as String?,
        spin: SpinInput.fromJson(j['spin'] as Map<String, dynamic>),
        settings: AppSettings.fromJson(j['settings'] as Map<String, dynamic>),
      );
}

final AppState appState = AppState();

class AppState extends ChangeNotifier {
  AppSettings settings = const AppSettings();
  Vec2 cue = const Vec2(63.5, 63.5);
  Vec2 object = const Vec2(150, 45);
  List<Vec2> obstacles = [];
  int pocketIndex = 2;
  SpinInput spin = const SpinInput();
  int plannerMax = 0, bankMax = 3, tab = 0;
  String? selectedKey;
  List<SavedShot> saved = [];

  TableSpec get table => TableSpec(
      length: settings.tableLength,
      ballRadius: settings.ballRadius,
      pocketMouth: settings.pocketMouth);

  List<BallPos> get obstacleBalls =>
      [for (var i = 0; i < obstacles.length; i++) BallPos('o$i', obstacles[i])];

  String ballName(String id) => id == 'cue'
      ? 'Cue ball'
      : id == 'obj'
          ? 'Object ball'
          : 'Obstacle ${int.parse(id.substring(1)) + 1}';

  List<ShotRoute> routesFor(int maxC) => ShotEngine(table).computeRoutes(
        cue: cue,
        object: object,
        obstacles: obstacleBalls,
        pocketIndex: pocketIndex,
        maxCushions: maxC,
        maxCutDeg: settings.maxCutDeg,
      );

  Vec2 ballPos(String id) => id == 'cue'
      ? cue
      : id == 'obj'
          ? object
          : obstacles[int.parse(id.substring(1))];

  void moveBall(String id, Vec2 p) {
    final c = table.clampCenter(p);
    if (id == 'cue') {
      cue = c;
    } else if (id == 'obj') {
      object = c;
    } else {
      obstacles[int.parse(id.substring(1))] = c;
    }
    notifyListeners();
  }

  void setTab(int t) {
    tab = t;
    notifyListeners();
  }

  void setPocket(int i) {
    pocketIndex = i;
    selectedKey = null;
    notifyListeners();
  }

  void setMax(bool bank, int n) {
    if (bank) {
      bankMax = n;
    } else {
      plannerMax = n;
    }
    notifyListeners();
  }

  void selectRoute(String key) {
    selectedKey = key;
    notifyListeners();
  }

  void setSpin(SpinInput s) {
    spin = s;
    notifyListeners();
  }

  void addObstacle() {
    if (obstacles.length >= 6) return;
    final t = table;
    final i = obstacles.length;
    obstacles.add(t.clampCenter(
        Vec2(t.length * (0.35 + 0.08 * i), t.width * (0.3 + 0.07 * i))));
    notifyListeners();
  }

  void removeObstacle() {
    if (obstacles.isEmpty) return;
    obstacles.removeLast();
    notifyListeners();
  }

  void resetLayout() {
    final t = table;
    cue = Vec2(t.length * 0.25, t.width * 0.5);
    object = Vec2(t.length * 0.6, t.width * 0.35);
    obstacles = [];
    selectedKey = null;
    notifyListeners();
  }

  Future<void> updateSettings(AppSettings s) async {
    settings = s;
    final t = table;
    cue = t.clampCenter(cue);
    object = t.clampCenter(object);
    obstacles = obstacles.map(t.clampCenter).toList();
    notifyListeners();
    await _persistSettings();
  }

  // ---- persistence (local storage) ----
  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final s = p.getString('settings_v1');
      if (s != null) {
        settings = AppSettings.fromJson(jsonDecode(s) as Map<String, dynamic>);
      }
      final l = p.getString('saved_v1');
      if (l != null) {
        saved = (jsonDecode(l) as List)
            .map((e) => SavedShot.fromJson(e as Map<String, dynamic>))
            .toList();
      }
    } catch (e) {
      debugPrint('load failed: $e');
    }
    resetLayout();
  }

  Future<void> _persistSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('settings_v1', jsonEncode(settings.toJson()));
  }

  Future<void> _persistSaved() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
        'saved_v1', jsonEncode(saved.map((s) => s.toJson()).toList()));
  }

  Future<void> saveShot(String name, bool bank) async {
    saved.insert(
        0,
        SavedShot(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          name: name.trim().isEmpty ? 'Shot ${saved.length + 1}' : name.trim(),
          createdAt: DateTime.now(),
          cue: cue,
          object: object,
          obstacles: List.of(obstacles),
          pocketIndex: pocketIndex,
          maxCushions: bank ? bankMax : plannerMax,
          bank: bank,
          routeKey: selectedKey,
          spin: spin,
          settings: settings,
        ));
    notifyListeners();
    await _persistSaved();
  }

  Future<void> deleteShot(String id) async {
    saved.removeWhere((s) => s.id == id);
    notifyListeners();
    await _persistSaved();
  }

  void openShot(SavedShot s) {
    settings = s.settings;
    cue = s.cue;
    object = s.object;
    obstacles = List.of(s.obstacles);
    pocketIndex = s.pocketIndex;
    spin = s.spin;
    selectedKey = s.routeKey;
    if (s.bank) {
      bankMax = s.maxCushions;
    } else {
      plannerMax = s.maxCushions;
    }
    tab = s.bank ? 2 : 1;
    notifyListeners();
  }
}
