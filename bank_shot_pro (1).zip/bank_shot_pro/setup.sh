#!/bin/sh
# Creates the Android wrapper with `flutter create`, then copies this
# project's sources into it. Requires Flutter SDK (3.19+) and Android SDK.
set -e
flutter create --org com.bankshotpro --project-name bank_shot_pro --platforms android ../bank_shot_pro_app
cp -r lib test pubspec.yaml ../bank_shot_pro_app/
cd ../bank_shot_pro_app
flutter pub get
flutter test
echo "Done. Run: cd ../bank_shot_pro_app && flutter run"
